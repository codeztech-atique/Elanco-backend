# Elanco-backend
Consume Elanco API and make in memory caching.

# Local Endpoint
https://localhost:8081/api

# Production Endpoint with In Memory Caching
https://ppaoiuojo1.execute-api.us-west-1.amazonaws.com/production/api

# Company provided Endpoints
https://engineering-task.elancoapps.com/api

# Postman Collection



